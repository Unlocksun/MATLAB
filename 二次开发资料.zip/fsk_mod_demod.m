%% FSK���ƽ��

% ��ʼ��
clc;
clear;
close all;

%% ��������
fd =  2000;     %�����ź�����2k
f1 =  8000;    %�ز�Ƶ��f1-8k
f2 =  24000;    %�ز�Ƶ��f2-16k
fs =  f1*32;     %������


%% ����ԭʼ�ź�
jd = [];
Nb = 8;
rd = rand(Nb,1);
for i = 1:length(rd)
    if(rd(i) > 0.5)
        jd(i) = 1;
    else
        jd(i) = 0; 
    end
end

jdn = repmat(jd,fs/fd,1)


jdnr = reshape(jdn,fs/fd*Nb,1)


subplot(6,1,1)
plot(jdnr)
ylim([-0.1,1.2])
xlim([1,1024])

%% �����ز�
t = 1/fs:1/fs:1/fs*(fs/fd*Nb); 
cosw1t = cos(t*f1*2*pi);
cosw2t = cos(t*f2*2*pi);
% subplot(6,1,2)
% plot(cosw1t)
% xlim([1,1024])
% subplot(6,1,3)
% plot(cosw2t)
% xlim([1,1024])

%% ����

%���ط�
for i = 1:length(jdnr)
    if(jdnr(i)==0)
       fskd(i) = cosw1t(i);
    else
       fskd(i) = cosw2t(i);
    end
end

%������λ����
% alpha = 0;
% for i = 1:length(jdnr)
%     fskd(i) = cos(alpha);
%     if(jdnr(i)==0)
%        alpha =  alpha + f1*2*pi/fs;
%     else
%        alpha =  alpha + f2*2*pi/fs;
%     end
% end

subplot(6,1,2)
plot(fskd)
xlim([1,1024])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% FSK���
%% ��ּ��

ddata = [];
half_wave = [];
for i=1:length(fskd)-20
    ddata(i) = fskd(i+1)-fskd(i);
end
% ddata = fskd .* cosw2t;
subplot(6,1,3)
plot(ddata)
xlim([1,1024])



%% ȫ������
whole_wave = [];
half_wave = [];
for i=1:length(ddata)
    if(ddata(i)>0)
        half_wave(i) = ddata(i);
        whole_wave(i) = ddata(i);
    else
        whole_wave(i) = -ddata(i);
        half_wave(i) = 0;
    end
end

subplot(6,1,4)
plot(whole_wave)
xlim([1,1024])


%% �����˲�
N= 256;
para = fir1(N,f1/fs); 

fird = filter2(para,1,whole_wave);
subplot(6,1,5)

fild = fird(128:1024+128-1);

plot((1:1:1024),fild);
xlim([1,1024])

%% �о�
demod = [];
Lel = 0.2;
for i = 1:Nb
   if(fild((i-1)*fs/fd+ fs/fd/2)>= Lel) 
       demod(i) = 1;
   else
       demod(i) = 0;
   end
end

subplot(6,1,6)
plot(demod);
% 







